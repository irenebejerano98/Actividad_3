#ifndef variables_h
#define variables_h

#include <DHT.h>
#include <LiquidCrystal_I2C.h>
#include <Servo.h>
#include <Adafruit_SSD1306.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <IRremote.h>

#define DHT_PINExt 5 //Pin digital del sensor DHT22 externo
#define DHT_PINInt 7 //Pin digital del sensor DHT22 interno
#define AIR_PIN A0 //Pin analógico del potenciómetro que simula calidad del aire
#define BUTTON_PIN 2 //Pin del boton para cambiar pantalla
#define LDR_PIN A1 //Pin analógico del sensor LDR
#define HEATER_PIN 3 //Pin del led rojo
#define FANS_PIN 4 //Pin del led azul
#define W_DIR_PIN A3 //Pin analógico del potenciómetro que simula dirección del viento
#define W_SPEED_PIN A2 //Pin analógico del potenciómetro que simula velocidad del viento
#define PIN_RECEIVER 6 //Pin del IR remote

#define SCREEN_WIDTH 128 //batería
#define SCREEN_HEIGHT 64 //batería
#define OLED_ADDR 0x3C //bateria 

//Configuramos dos sensores
DHT dhtExt(DHT_PINExt, DHT22);
DHT dhtInt(DHT_PINInt, DHT22);
LiquidCrystal_I2C lcd(0x27, 20, 4);
//Asignamos IR receptor lo que entra por 2

volatile bool buttonPressed = false;
volatile int screenIndex = 0;
unsigned long lastScreenUpdate = 0;  // Controla el intervalo de actualización de la pantalla
const unsigned long SCREEN_UPDATE_INTERVAL = 500;  // Actualizar pantalla cada 500ms

unsigned long lastDHTReadExt = 0;
unsigned long lastDHTReadInt = 0;
unsigned long lastLDRRead = 0;
unsigned long lastAIRRead = 0;
unsigned long lastWINDRead = 0;
unsigned long lastServoRead = 0;

float temperatureExt = 0.0;
float humidityExt = 0.0;
float temperatureInt = 0.0;
float humidityInt = 0.0;

const unsigned long DHT_INTERVALExt = 5000;  // Actualizar cada 5 segundos
const unsigned long DHT_INTERVALInt = 1000;  // Actualizar cada 1 segundos
const unsigned long LDR_INTERVAL = 2000;  // Actualizar cada 2 segundos
const unsigned long AIR_INTERVAL = 3000;  // Actualizar cada 3 segundos
const unsigned long WIND_INTERVAL = 4000;  // Actualizar cada 4 segundos
const unsigned long SERVO_INTERVAL = 500; //actualizar cada 0,5 segundos

float lux;

String airStatus="";

int windDirection;
int windSpeed = 0;


//servo
Servo servoCold;     //objeto de tipo servo, referenciar al servo/motor
int PINSERVOCOLD = 8;    //Pin conectado el servo
Servo servoHot;
int PINSERVOHOT = 12;
//calcular la posición aproximada de los grados  0 y 180 (prueba y error)  1400 = 90 grados
int PULSOMIN = 500;  //Pulso de (1000 microseg) 1ms equivale a 0 grados (500 casi exacto a 0 grados)
int PULSOMAX = 2400;  //Pulso de (2000 microseg) 2ms equivale a 180 grados (2400 casi exacto a 180 grados)

float tempMax = 28.0;
float tempMin = 22.0;

//bateria
Adafruit_SSD1306 oled(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, 6);
float bateria = 100.0;


//Receptor IR
int btn_value = 152;





#endif
